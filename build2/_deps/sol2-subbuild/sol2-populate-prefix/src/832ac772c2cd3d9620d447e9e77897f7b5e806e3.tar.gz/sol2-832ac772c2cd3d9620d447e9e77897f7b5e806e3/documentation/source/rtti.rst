run-time type information (rtti)
================================
*because somebody's going to want to shut this off, too...*

sol does not use RTTI.

.. _an issue: https://github.com/ThePhD/sol2/issues
