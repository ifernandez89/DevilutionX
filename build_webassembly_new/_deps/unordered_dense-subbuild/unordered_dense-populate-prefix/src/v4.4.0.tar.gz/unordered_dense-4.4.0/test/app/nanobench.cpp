#define ANKERL_NANOBENCH_IMPLEMENT
#include <third-party/nanobench.h>
